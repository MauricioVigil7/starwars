# InspeccionRiesgo

## Comandos
### Construir
sam build --profile xxxxx
sam deploy --profile xxxxx --capabilities CAPABILITY_AUTO_EXPAND CAPABILITY_IAM CAPABILITY_NAMED_IAM --guided
