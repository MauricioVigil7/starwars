# InspeccionRiesgo

## Comandos
### Construir
sam build --profile stefanini
sam deploy --profile stefanini --capabilities CAPABILITY_AUTO_EXPAND CAPABILITY_IAM CAPABILITY_NAMED_IAM --guided
