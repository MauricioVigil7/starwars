
const assert = require('assert');
const handler = require('../Functions/StarShips/handler.js');
describe ('procesarGet',function(){
    describe ('StarShips',function(){
        //assert.equal(typeof handler, 'object');
        //assert.equal(typeof handler.procesarGet, 'function');
    
    });
});




    
